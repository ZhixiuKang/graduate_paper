#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define ROWS		(int)480
#define COLUMNS		(int)640

void clear( unsigned char image[][COLUMNS]);
void header( int row, int col, unsigned char head[32]);
double dotProduct(double x[3], double y[3]);

int main( int argc, char **argv )
{
	int				i, j, k;
	FILE			*fp;
	unsigned char	image[ROWS][COLUMNS], head[32];
	char			filename[9][50];

	/*
	 * @param N surface normal
	 */
	double          N[3];        
	/*
	 * @param V viewing direction, always (0, 0, 1)
	 */	
	double          V[3] = {0,0,1};        
	/*
	 * @param H angular bisector between V and S
	 */
    double          H[3];       
	/*
	 * @param L scene radiance
	 */
    double          L[ROWS][COLUMNS]; 

	/* Define the 9 configurations */

	/* 
	 * @param S	source direction
	 */
	double S[9][3] = {{0, 0, 1}, {1 / sqrt(3), 1 / sqrt(3), 1 / sqrt(3)}, {1, 0, 0}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1}};

	/* 
	 * @param r	radius
	 */
	double r[9] = {50, 50, 50, 10, 100, 50, 50, 50, 50};

	/* 
	 * @param a	constant
	 */
	double a[9] = {0.5, 0.5, 0.5, 0.5, 0.5, 0.1, 1, 0.5, 0.5};
	
	/* 
	 * @param m	related to the surface roughness
	 */
	double m[9] = {1, 1, 1, 1, 1, 1, 1, 0.1, 10000};

	strcpy(filename[0], "imageA");
	strcpy(filename[1], "imageB");
	strcpy(filename[2], "imageC");
	strcpy(filename[3], "imageD");
	strcpy(filename[4], "imageE");
	strcpy(filename[5], "imageF");
	strcpy(filename[6], "imageG");
	strcpy(filename[7], "imageH");
	strcpy(filename[8], "imageI");

	header ( ROWS, COLUMNS, head );

	/* Use the 9 configurations and generate 9 images respectively */
	for (k = 0; k < 9; k++) {
		// Compute the angular bisector between V and S
		for (i = 0; i < 3; i++) {
			H[i] = (V[i] + S[k][i]) / sqrt((pow(V[0] + S[k][0], 2) + pow(V[1] + S[k][1], 2) + pow(V[2] + S[k][2], 2)));
		}

		for (i = 0; i < ROWS; i++) {
			for (j = 0; j < COLUMNS; j++){
				// 240 is the x origin
				int x = i - 240;
				// 320 is the y origin
				int y = j - 320;

				// Compute the surface normal
				double p = (-1) * x / sqrt(pow(r[k], 2) - pow(x, 2) - pow(y, 2));
				double q = (-1) * y / sqrt(pow(r[k], 2) - pow(x, 2) - pow(y, 2));
				N[0] = p / sqrt(pow(p, 2) + pow(q, 2) + 1);
				N[1] = q / sqrt(pow(p, 2) + pow(q, 2) + 1);
				N[2] = 1 / sqrt(pow(p, 2) + pow(q, 2) + 1);

				// Compute the Lambertian reflectance
				double Ll = dotProduct(N, S[k]);

				// Compute the angle between N and H
				double alpha = acos(dotProduct(N, H));

				// Compute the Specular reflectance
				double Ls = exp(-pow(alpha / m[k], 2));

				// Computer the Scene radiance
				L[i][j] = a[k] * Ll + (1 - a[k]) * Ls;
			}
		}
		
		/* Compute the max */
		double max = 0.0;
		for (i = 0; i < ROWS; i++) {
			for (j = 0; j < COLUMNS; j++){
				if (L[i][j] > max)
					max = L[i][j];
			}
		}

		/* Normalize */
		for (i = 0; i < ROWS; i++) {
			for (j = 0; j < COLUMNS; j++) {
				image[i][j] = (float)L[i][j] / max * 255;
			}
		}

		/* Write image */
		if (!( fp = fopen( strcat( filename[k], ".ras" ), "wb" ) )) {
			fprintf( stderr, "error: could not open %s\n", filename[k] );
			exit( 1 );
		}
		fwrite( head, 4, 8, fp );
		for(i = 0; i < ROWS; i++) {
			fwrite(image[i], 1, COLUMNS, fp);
		}
		fclose( fp );	
	}

	return 0;
}

/* To obtain the angles */
double dotProduct(double x[3], double y[3]) {
	double tmp = 0.0;
	for (int i = 0; i < 3; i++) {
		tmp = tmp + x[i] * y[i];
	}
	return tmp;
}

void clear( unsigned char image[][COLUMNS] )
{
	int	i,j;
	for ( i = 0 ; i < ROWS ; i++ )
		for ( j = 0 ; j < COLUMNS ; j++ ) image[i][j] = 0;
}

void header( int row, int col, unsigned char head[32] )
{
	int *p = (int *)head;
	char *ch;
	int num = row * col;

	/* Choose little-endian or big-endian header depending on the machine. Don't modify this */
	/* Little-endian for PC */
	
	*p = 0x956aa659;
	*(p + 3) = 0x08000000;
	*(p + 5) = 0x01000000;
	*(p + 6) = 0x0;
	*(p + 7) = 0xf8000000;

	ch = (char*)&col;
	head[7] = *ch;
	ch ++; 
	head[6] = *ch;
	ch ++;
	head[5] = *ch;
	ch ++;
	head[4] = *ch;

	ch = (char*)&row;
	head[11] = *ch;
	ch ++; 
	head[10] = *ch;
	ch ++;
	head[9] = *ch;
	ch ++;
	head[8] = *ch;
	
	ch = (char*)&num;
	head[19] = *ch;
	ch ++; 
	head[18] = *ch;
	ch ++;
	head[17] = *ch;
	ch ++;
	head[16] = *ch;
	

	/* Big-endian for unix */
	/*
	*p = 0x59a66a95;
	*(p + 1) = col;
	*(p + 2) = row;
	*(p + 3) = 0x8;
	*(p + 4) = num;
	*(p + 5) = 0x1;
	*(p + 6) = 0x0;
	*(p + 7) = 0xf8;
*/
}
